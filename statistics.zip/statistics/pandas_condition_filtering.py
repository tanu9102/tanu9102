


#filter row based on gender
print(df[df['gender']=='Male'])
