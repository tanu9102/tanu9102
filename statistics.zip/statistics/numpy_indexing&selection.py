#numpy_indexing_and_selection
import numpy  as np
#creating a sample array
arr=np.arange(0,11)
print("Initial array :",arr)

#Bracket indexing and selection
#GET A VALUE AT AND INDEX
print("value at index 8:",arr[8])

#get values in a range
print("value in range [1:5]:",arr[1:5])
print("value in range [0:5]:",arr[0:5])

#broadcatsing
#setting values with index range
arr[0:5]=100
print("after broadcasting [0:5] with 100:",arr)

#reset array
arr=np.arange(0,11)
print("reset array :",arr)

#imporatnt notes on slices
slice_of_arr=arr[0:6]
print("slice of array [0:6]:",slice_of_arr)

#change slice
slice_of_arr[:]=99
print("after modifying slice :",slice_of_arr)
print("orginal array after modfying slice:",arr)

#to get a copy
arr_copy=arr.copy()
print("copy of array :",arr_copy)
arr_copy[:]=22

#2d array
arr_2d=np.array(([5,10,15],[20,25,30],[35,40,45]))
print("2d array:\n",arr_2d)

#indexing row
print("second row of 2d array :",arr_2d[1])


#getting indiviual element value
print("Element at [1,0]:",arr_2d[1][0])
print("element at [1,0] (alternative syntax):",arr_2d[1,0])

#2d array slicing
print("shape(2,2) from top right corner :\n",arr_2d[:2,1:])
print("bottom row :",arr_2d[2])
print("bottom row (alternative syntax):",arr_2d[2,:])

#conditional selection
arr=np.arange(1,11)
print("Array for conditional selection :",arr)

#check condition
print("condition arr > 4:",arr>4)

#store boolean results in another array
bool_arr=arr>4
print("boolean array for arr >4",bool_arr)

#select elements where conditions is True
print("elements where arr >4",arr[bool_arr])

#using condition directly in selection
print("elements where arr >2",arr[arr>2])

#using a variable for condition
x=2
print("Elements where arr > x(x=2):",arr[arr>x])




