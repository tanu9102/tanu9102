import numpy as np
#statistical properties of numpy arrays
#creating a sample array
arr=np.arange(0,10)
print("Array:",arr)

#Shape of the array
print(arr.shape)

#summary statistics
print("Sum of elements :",arr.sum())
print("Mean of elements :",arr.mean())
print("Maximum value :",arr.max())
print("Minimum value:",arr.min())
print("Variance :",arr.var())
print("Standard Deviation :",arr.std())
