import numpy as np
from numpy.ma.core import reshape

#Basic arrays
arr1=np.array([1,2,3,4])# 1D array from a list
arr2=np.array([[1,2,3],[4,5,6]]) #2D array from a nested list
arr3=np.array((7,8,9)) # 1D array from a tuple
print("Basic Arrays:\n", arr1,"\n",arr2, "\n",arr3)

#Basic arrays
arr1=np.array([1,2,3,4])# 1D array from a list
arr2=np.array([[1,2,3],[4,5,6]]) #2D array from a nested list
arr3=np.array((7,8,9)) # 1D array from a tuple
print("Basic Arrays:\n", arr1,"\n",arr2, "\n",arr3)

empty=np.empty((2,2)) # 2*2 uninitialized array
full=np.full((2,2),7) #2*2 array filled with 7
print("\nEmpty:\n",empty,"\nFull:\n")

#Creating arrays with range
#arange:Use when you know the step/gap between two consecutive numbers
#linspace:Use when you know the number of elements, not the step/gap
#range_arr=np.arange(0,10,2)


#Random arrays
rand=np.random.rand(2,3)
rand_int=np.random.randint(1,10,(2,2))
rand_normal=np.random.randn(2,3)
rand_custom_normal=np.random.normal(5,2,(2,3))
print("\nRandon Arrays:\n",rand,"\nRandom Integer:\n",rand_int,"\nStandard Normal:\n",rand_normal,"\n Custom Normal:\n",rand_custom_normal)

#reshaping and initializing shapes
reshaped=np.arange(12).reshape(3,4)
init_like=np.zeros_like(reshaped)
print("\n Reshaped Array:\n",reshaped)
print("\n Initialized like reshaped:\n",init_like)
